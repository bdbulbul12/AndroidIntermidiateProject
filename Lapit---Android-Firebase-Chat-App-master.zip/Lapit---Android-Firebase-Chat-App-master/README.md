# Lapit---Android-Firebase-Chat-App

## Warning

The Gradle file has been edited for security purpose. You need to include your own project's gradle Fields in "google services.json" file.
Without that the app wont run.

## Before you continue

The App is Still work in progress so this may contain some errors. The source code will be updated along with the upcoming tutorials.
As the project is based on a youtube tutorial series "Lapit Chat App".

## Watch Lapit Chat App Tutorial Series

[Watch the entire Lapit Chat App Series](https://www.youtube.com/playlist?list=PLGCjwl1RrtcQ3o2jmZtwu2wXEA4OIIq53)

## Updates

[ 8 Aug, 2017 ] - First Upload with Code of First 30 Tutorials
